# Infinite-Runner
It's a 2D game made in C# with Unity Game Engine as a Project to get insight of game building.
To Download full Project go to https://drive.google.com/open?id=0BzEWBx4Ns_EQUE9kaWxOcjgzTjQ
